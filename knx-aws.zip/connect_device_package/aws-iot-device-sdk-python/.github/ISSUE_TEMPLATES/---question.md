---
name: "\U0001F4AC Questions / Help"
about: Make sure your question hasn't been asked before
title: ''
labels: guidance, needs-triage
assignees: ''

---

Confirm by changing [ ] to [x] below:
- [ ] I've searched for [previous similar issues](https://github.com/aws/aws-iot-device-sdk-python/issues/) and didn't find any solution

**Known Issue**
- [ ] I'm using ATS data type endpoint: the endpoint should look like `<prefix>-ats.iot.<region>.amazonaws.com`

**Platform/OS/Device**
What are you running the sdk on?

**Describe the question**
