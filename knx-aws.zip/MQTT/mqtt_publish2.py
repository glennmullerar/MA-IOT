import paho.mqtt.client as mqtt
from random import randrange, uniform
import time

mqttBroker = "mqtt.eclipseprojects.io"
client = mqtt.Client("Humidity")
client.connect(mqttBroker)

while True:
    randNumber = randrange(10)
    client.publish("HUMIDITY", randNumber)
    print("Just published " + str(randNumber) + " to Topic HUMIDITY")
    time.sleep(1)